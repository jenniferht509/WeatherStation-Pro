from machine import Pin, I2C, PWM, ADC
import time, dht, ssd1306

# --- Capteurs ---
dht1 = dht.DHT22(Pin(2))   # capteur zone 1
dht2 = dht.DHT22(Pin(3))   # capteur zone 2
i2c = I2C(0, scl=Pin(5), sda=Pin(4))  # bus I2C pour l’OLED
mq = ADC(Pin(26))          # capteur de gaz MQ-135

# --- Actionneurs ---
led_r = Pin(10, Pin.OUT)
led_g = Pin(11, Pin.OUT)
led_b = Pin(12, Pin.OUT)
servo = PWM(Pin(15)); servo.freq(50)
buzzer = PWM(Pin(16)); buzzer.freq(1000)

# --- Boutons ---
btn_nav = Pin(17, Pin.IN, Pin.PULL_UP)
btn_reset = Pin(18, Pin.IN, Pin.PULL_UP)

# --- OLED ---
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

# --- Fonctions ---
def servo_angle(angle):
    duty = int(1638 + (angle/180)*6553)
    servo.duty_u16(duty)

def buzzer_on(freq=1000):
    buzzer.freq(freq)
    buzzer.duty_u16(32768)

def buzzer_off():
    buzzer.duty_u16(0)

def led_color(r,g,b):
    led_r.value(r); led_g.value(g); led_b.value(b)

# --- Variables ---
min_temp, max_temp = 999, -999
min_hum, max_hum = 999, -999
screen = 1

# --- Boucle infinie ---
while True:
    # Mesures
    dht1.measure(); dht2.measure()
    t1, h1 = dht1.temperature(), dht1.humidity()
    t2, h2 = dht2.temperature(), dht2.humidity()
    gaz = mq.read_u16()

    # Mise à jour min/max
    min_temp = min(min_temp, t1, t2)
    max_temp = max(max_temp, t1, t2)
    min_hum = min(min_hum, h1, h2)
    max_hum = max(max_hum, h1, h2)

    # Affichage OLED
    oled.fill(0)
    if screen == 1:
        oled.text("Zone1 T:{}C".format(t1), 0, 0)
        oled.text("Zone2 T:{}C".format(t2), 0, 10)
    elif screen == 2:
        oled.text("Hum1:{}%".format(h1), 0, 0)
        oled.text("Hum2:{}%".format(h2), 0, 10)
    elif screen == 3:
        oled.text("Gaz:{}".format(gaz), 0, 0)
        oled.text("Statut:OK", 0, 10)
    elif screen == 4:
        oled.text("Tmin:{}C".format(min_temp), 0, 0)
        oled.text("Tmax:{}C".format(max_temp), 0, 10)
        oled.text("Hmin:{}%".format(min_hum), 0, 20)
        oled.text("Hmax:{}%".format(max_hum), 0, 30)
    oled.show()

    # --- Bouton navigation ---
    if btn_nav.value() == 0:
        time.sleep_ms(20)
        if btn_nav.value() == 0:
            # Action spéciale à chaque appui
            servo_angle(90)          # le servo bouge
            buzzer_on(1200)          # bip court
            time.sleep(0.2)
            buzzer_off()
            servo_angle(0)           # retour à 0
            led_color(0,0,0)         # LED éteinte
            time.sleep(0.2)

            # Changement d’écran
            screen += 1
            if screen > 4:
                screen = 1

            # Attente relâchement du bouton
            while btn_nav.value() == 0:
                time.sleep_ms(10)

    # --- Bouton reset ---
    if btn_reset.value() == 0:
        min_temp, max_temp = 999, -999
        min_hum, max_hum = 999, -999
        buzzer_off(); led_color(0,1,0); servo_angle(0)
        oled.fill(0); oled.text("RESET OK", 0, 0); oled.show()
        while btn_reset.value() == 0:
            time.sleep_ms(10)

    # --- Alertes automatiques ---
    if t1 > 33 or t2 > 33:
        led_color(1,0,0); buzzer_on(800); servo_angle(90)
    elif h1 > 80 or h2 > 80:
        led_color(0,0,1); buzzer_on(1200)
    elif gaz > 30000:
        led_color(1,0,0); buzzer_on(1500)
    else:
        led_color(0,1,0); buzzer_off(); servo_angle(0)

    time.sleep(0.1)
